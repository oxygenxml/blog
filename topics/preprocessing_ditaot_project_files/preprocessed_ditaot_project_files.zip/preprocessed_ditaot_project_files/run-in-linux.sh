#!/bin/bash
rm -rf ./out

export DITAOT=$(dirname $(dirname $(which dita)))
export SAXON_JAR=~/saxon/saxon-he-10.6.jar

echo "Creating preprocessed DITA-OT project file..."
java \
  -jar ${SAXON_JAR} \
  -xsl:frameworks/dita/preprocess_project_file.xsl \
  -s:project_files/project.xml \
  -o:project_files/project.xml-preprocessed.xml

echo "Publishing preprocessed DITA-OT project file..."
${DITAOT}/bin/dita --project project_files/project.xml-preprocessed.xml -t temp --verbose

rm project_files/project.xml-preprocessed.xml

# you can also use this if Ant is configured to use Saxon for <xslt>
#ant \
# -buildfile ./frameworks/dita/build_dita_project_preprocessed.xml \
# -Dproject.file=$(realpath project_files/deliverables-all.xml) \
# -Dadditional.args="-verbose" \
# -Ddita-ot.dir=${DITAOT}

